# ruff: noqa: I001

import pandas as pd
import pytest

from experiments.train import _evaluate_validation, _training_windows


class _FixedProbModel:
    def predict(self, features: pd.DataFrame):
        # The halted row receives the highest score on every day.  If validation
        # substitutes Trading_Halt=0, it would incorrectly be selected instead.
        return [0.99 if code == "HALTED" else 0.80 for code in features.index]


def _validation_frame() -> pd.DataFrame:
    dates = pd.date_range("2024-01-01", periods=5, freq="B")
    rows = []
    for date in dates:
        rows.extend(
            [
                {"Date": date, "Code": "HALTED", "Close": 100.0, "Trading_Halt": 1, "Y_Label": 2, "feature": 1.0},
                {"Date": date, "Code": "TRADEABLE", "Close": 100.0, "Trading_Halt": 0, "Y_Label": 1, "feature": 2.0},
            ]
        )
    return pd.DataFrame(rows).set_index("Code", drop=False)


def test_validation_excludes_halted_high_probability_signals() -> None:
    metrics = _evaluate_validation(
        {"strategy": {"prob_threshold": 0.65, "top_n": 1}},
        {"fold_id": 0, "name": "fold", "train_start": "2023-01-01", "train_end": "2023-12-31"},
        0,
        _FixedProbModel(),
        _validation_frame(),
        ["feature"],
    )

    assert metrics["selected_signal_count"] == 5
    assert metrics["selected_success_count"] == 0


def test_validation_rejects_missing_trade_metadata() -> None:
    frame = _validation_frame().drop(columns=["Trading_Halt"])
    with pytest.raises(ValueError, match="메타데이터"):
        _evaluate_validation(
            {"strategy": {}},
            {"fold_id": 0, "name": "fold", "train_start": "2023-01-01", "train_end": "2023-12-31"},
            0,
            _FixedProbModel(),
            frame,
            ["feature"],
        )


def test_final_holdout_uses_full_training_period_without_label_leakage() -> None:
    split = {
        "train_start": "2022-01-01",
        "train_end": "2024-12-31",
        "test_start": "2025-01-08",
        "test_end": "2025-12-31",
    }

    assert _training_windows(split, embargo_days=7, skip_validation=True) == (
        "2024-12-31",
        "2024-12-31",
        "2024-12-31",
        "2024-12-31",
        None,
    )


def test_standard_run_keeps_internal_validation_window() -> None:
    split = {
        "train_start": "2022-01-01",
        "train_end": "2024-12-31",
        "test_start": "2025-01-08",
        "test_end": "2025-12-31",
    }

    assert _training_windows(split, embargo_days=7, skip_validation=False) == (
        "2024-06-30",
        "2024-07-06",
        "2024-07-07",
        "2024-12-31",
        "2025-01-07",
    )


def test_cached_predictions_cannot_skip_missing_fold_validation_model(tmp_path, monkeypatch):
    from experiments import config as config_module, experiment_utils, train
    config = {'feature_columns': ['kmid'], 'cache_dir': str(tmp_path),
              'labels': {'horizon': 5}, 'data': {}, 'training': {'skip_validation': False}}
    split = {'train_start': '2023-01-01', 'train_end': '2023-12-31',
             'test_start': '2024-01-08', 'test_end': '2024-12-31', 'fold_id': 0}
    (tmp_path / 'test_predictions.parquet').touch()
    monkeypatch.setattr(config_module, 'load_experiment_config', lambda _: config)
    monkeypatch.setattr(train, 'resolve_splits', lambda _: [split])
    monkeypatch.setattr(train, 'generate_dataset_hash', lambda *_: 'dataset')
    monkeypatch.setattr(train, 'generate_predictions_hash', lambda *_: 'test')
    monkeypatch.setattr(train, 'result_dir', lambda *_: str(tmp_path))
    monkeypatch.setattr(train, 'find_processed_dir', lambda *_: str(tmp_path))
    monkeypatch.setattr(train, 'resolve_tickers', lambda *_: [])
    monkeypatch.setattr(train, 'cache_dir', lambda *_: str(tmp_path))
    monkeypatch.setattr(experiment_utils, 'load_predictions', lambda *_: pd.DataFrame())
    with pytest.raises(FileNotFoundError, match='requires every fold model'):
        train.main('unused.yaml')
