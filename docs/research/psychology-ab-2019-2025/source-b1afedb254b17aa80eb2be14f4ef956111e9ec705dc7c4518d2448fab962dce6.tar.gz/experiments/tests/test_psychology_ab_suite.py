"""A small actual four-model run checks paired samples, reporting and restart."""

import copy
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml
from experiments import run_backtest, run_ml_evaluation, run_psychology_ab, train
from experiments.config import load_experiment_config
from experiments.dataset.pipeline import preprocess_dataset
from experiments.tests.test_local_pipeline_contract import local_dataset as dataset_fixture
from shared.io import atomic_json, sha256


@pytest.fixture
def local_dataset(tmp_path):
    return dataset_fixture.__wrapped__(tmp_path)


def test_paired_suite_trains_reports_and_resumes(local_dataset, tmp_path, monkeypatch):
    _, settings, source_config, template_path = local_dataset
    source = Path(settings["root"])
    raw_path = source / "raw/005930.parquet"
    raw = pd.read_parquet(raw_path)
    raw.loc[80, "Institution_BuyAmount"] = np.nan
    raw.to_parquet(raw_path, index=False)
    manifest_path = source / "dataset_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    manifest.update(end_date=settings["collection"]["end_date"])
    manifest["raw_files"][raw_path.name] = sha256(raw_path)
    atomic_json(manifest_path, manifest)
    preprocess_dataset(source_config)
    before = sha256(raw_path)
    dataset = copy.deepcopy(settings)
    dataset["root"] = str(tmp_path / "snapshot")
    dataset["dataset_id"] = "paired_smoke"
    dataset_path = tmp_path / "snapshot.yaml"
    dataset_path.write_text(yaml.safe_dump(dataset))
    base = yaml.safe_load(template_path.read_text())
    templates = {}
    for horizon in (5, 20):
        config = copy.deepcopy(base)
        config["labels"].update(horizon=horizon, up_mult=1.75 if horizon == 5 else 3.75,
                                down_mult=1.5 if horizon == 5 else 3.0)
        config["backtest"].update(capital_mode="independent_year", max_holding_days=horizon,
                                  up_mult=config["labels"]["up_mult"], down_mult=config["labels"]["down_mult"])
        path = tmp_path / f"template_h{horizon}.yaml"
        path.write_text(yaml.safe_dump(config))
        templates[f"h{horizon}"] = str(path)
    plan = {"dataset": str(dataset_path), "source_dataset_root": str(source),
            "templates": templates, "data": base["data"], "n_jobs": 1}
    output = tmp_path / "suite"
    run_psychology_ab.run(plan, output, prepare_only=True)
    prepared = json.loads((output / "prepared.json").read_text())
    assert prepared["paired_features"]["h5"]["eligible_rows"] > 0
    configs = {name: load_experiment_config(path) for name, path in prepared["configs"].items()}
    b_root = Path(configs["h5_B"]["features"]["materialized_dir"])
    b = pd.read_parquet(b_root / "005930.parquet")
    assert len(b) == len(raw)
    assert not b.loc[80:99, "SampleEligible"].any()
    assert not b.loc[b.SampleEligible, list(run_psychology_ab.TREATMENT_FEATURES)].isna().any().any()
    # Keep the process boundary mocked; run real canonical training and both evaluators.
    calls = []
    handlers = {"experiments.train": train.main, "experiments.run_ml_evaluation": run_ml_evaluation.main,
                "experiments.run_backtest": run_backtest.main}

    def execute(command, **kwargs):
        calls.append(command[3])
        handlers[command[3]](command[-1])

    monkeypatch.setattr(run_psychology_ab.subprocess, "run", execute)
    run_psychology_ab.run(plan, output)
    assert len(calls) == 12
    assert json.loads((output / "status.json").read_text())["status"] == "complete"
    comparison = pd.read_csv(output / "comparison_by_year.csv")
    assert comparison.horizon.tolist() == [5, 20]
    assert comparison.sample_count.gt(0).all()
    assert (output / "REPORT.md").is_file()
    run_psychology_ab.run(plan, output)
    assert len(calls) == 12
    assert sha256(raw_path) == before
    (output / "configs/h5_A.yaml").write_text("modified")
    with pytest.raises(ValueError, match="Generated config changed"):
        run_psychology_ab.run(plan, output)


def test_suite_preserves_source_and_rejects_modified_snapshot(local_dataset, tmp_path):
    _, settings, _, _ = local_dataset
    source = Path(settings["root"])
    manifest_path = source / "dataset_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    manifest["end_date"] = settings["collection"]["end_date"]
    atomic_json(manifest_path, manifest)
    settings = dict(settings, root=str(tmp_path / "snapshot"))
    config_path = tmp_path / "snapshot.yaml"
    config_path.write_text(yaml.safe_dump(settings))
    run_psychology_ab.snapshot_dataset(source, config_path)
    path = tmp_path / "snapshot/raw/005930.parquet"
    path.write_bytes(b"damaged")
    with pytest.raises(ValueError, match="Snapshot input modified"):
        run_psychology_ab.snapshot_dataset(source, config_path)


def test_committed_suite_covers_seven_years_with_identical_templates():
    from experiments.config import CHART_ROOT, read_yaml
    from experiments.experiment_utils import resolve_splits

    plan = read_yaml(CHART_ROOT / run_psychology_ab.DEFAULT_CONFIG)
    splits = resolve_splits({"data": plan["data"]})
    assert len(splits) == 7
    assert splits[0]["train_start"] == "2016-01-01"
    assert splits[-1]["train_end"] == "2024-12-31"
    assert splits[-1]["test_end"] == "2025-12-31"
    assert [pd.Timestamp(s["test_start"]).year for s in splits] == list(range(2019, 2026))
    assert plan["n_jobs"] == 2
