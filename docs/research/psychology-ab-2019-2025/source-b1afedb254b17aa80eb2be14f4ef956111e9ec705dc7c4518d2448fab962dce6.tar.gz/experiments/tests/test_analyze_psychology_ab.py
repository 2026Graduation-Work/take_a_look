"""Accounting and linkage edge cases for saved-result attribution."""

import copy
import json

import numpy as np
import pandas as pd
import pytest
from experiments.analyze_psychology_ab import (
    annual_ledger,
    block_intervals,
    candidate_signals,
    cash_history,
    daily_stock_pnl,
    link_candidates,
    load_suite,
    match_trades,
    paired_history,
    score_bin,
    verify_annual_artifacts,
)
from shared.io import sha256


def test_threshold_ties_alphanumeric_codes_and_calendar_boundaries():
    days = pd.bdate_range("2020-12-24", periods=6)
    codes = ["000001", "000002", "000003", "000004", "000005", "00001A"]
    prices = pd.MultiIndex.from_product([days, codes], names=["Date", "Code"]).to_frame(index=False)
    prices = prices.assign(Open=100., High=101., Low=99., Close=100., Sigma=.01,
                           Trading_Halt=0, UniverseEligible=True)
    predictions = prices[["Date", "Code"]].assign(prob_up=.65)
    # The gap represents an embargo, a signal cannot leap across it.
    predictions = predictions.loc[~predictions.Date.eq(days[2])].copy()
    predictions.loc[predictions.Date.eq(days[3]), "prob_up"] = .6499999
    prices.loc[prices.Date.eq(days[1]) & prices.Code.eq("000001"), "Trading_Halt"] = 1
    config = {"contract_version": 3, "strategy": {"score_column": "prob_up", "prob_threshold": .65, "top_n": 5},
              "backtest": {"signal_lag_days": 1}}
    result = candidate_signals(config, predictions.sample(frac=1, random_state=42), prices)
    first = result.loc[result.Date.eq(days[0])].set_index("Code")
    assert first.threshold_pass.all()
    assert first.selected.sum() == 5
    assert not first.loc["00001A", "selected"]
    assert first.loc["000001", "rank"] == 1
    assert not first.loc["000001", "entry_allowed"]
    assert not result.loc[result.Date.eq(days[1]), "entry_allowed"].any()
    assert not result.loc[result.Date.eq(days[3]), "selected"].any()
    assert result.loc[result.Date.eq(days[-1]), "entry_date"].isna().all()
    # The production caller slices years before generating signals.
    boundary_prices = prices.loc[prices.Date.dt.year.eq(2020)]
    boundary_predictions = predictions.loc[predictions.Date.dt.year.eq(2020)]
    annual = candidate_signals(config, boundary_predictions, boundary_prices)
    assert annual.loc[annual.Date.eq(boundary_prices.Date.max()), "entry_date"].isna().all()
    assert score_bin(pd.Series([0., .5, .6, .65, .7, 1.])).tolist() == [
        "[0,0.50)", "[0.50,0.60)", "[0.60,0.65)", "[0.65,0.70)", "[0.70,1]", "[0.70,1]",
    ]


def test_paired_labels_include_unobserved_tail_and_reject_mismatch():
    history = pd.DataFrame({"Date": pd.to_datetime(["2020-01-02", "2020-01-03"]),
                            "Code": ["00001A", "000001"], "fold_id": [0, 0],
                            "Y_Label": [2., np.nan], "label_observed": [True, False],
                            "Prob": [.7, .3], "prob_up": [.7, .3]})
    b = history.assign(Prob=[.8, .4], prob_up=[.8, .4])
    paired = paired_history(history, b)
    assert len(paired) == 2
    assert paired.label_observed.sum() == 1
    b.loc[1, "fold_id"] = 1
    with pytest.raises(ValueError, match="folds"):
        paired_history(history, b)
    b = history.copy()
    b.loc[1, "Y_Label"] = 1
    with pytest.raises(ValueError, match="observation mask"):
        paired_history(history, b)


def test_candidate_linking_held_cash_sigma_unknown_and_orphan():
    date = pd.Timestamp("2020-01-03")
    signals = pd.DataFrame({"Date": date - pd.Timedelta(days=1), "Code": ["000001", "000002", "000003", "000004", "000005", "00001A"],
                            "selected": True, "entry_allowed": [True, True, True, True, False, True],
                            "entry_date": date})
    orders = pd.DataFrame({"date": [date + pd.Timedelta(hours=10)] * 2,
                           "code": ["000001", "999999"], "side": ["buy", "buy"]})
    ledger = pd.DataFrame({"Code": ["000002"], "entry_time": [date - pd.Timedelta(days=1)],
                           "exit_time": [date + pd.Timedelta(days=1)], "status": ["Open"]})
    report = {"exclusions": [{"date": str(date.date()), "code": "000003", "reason": "insufficient_cash"},
                              {"date": str(date.date()), "code": "000004", "reason": "signal_sigma_warmup"}]}
    result, orphans = link_candidates(signals, ledger, orders, report)
    assert result.execution_result.tolist() == ["filled", "already_held", "insufficient_cash", "signal_sigma_warmup", "entry_ineligible", "unknown"]
    assert orphans[0]["Code"] == "999999"
    ledger.loc[0, "status"] = "Closed"
    ledger.loc[0, "exit_time"] = date + pd.Timedelta(hours=9)
    result, _ = link_candidates(signals, ledger, orders, report)
    assert result.loc[1, "execution_result"] == "unknown"


def test_cash_snapshot_includes_opening_exit_and_excludes_writeoff_proceeds():
    orders = pd.DataFrame({"date": pd.to_datetime(["2020-01-02 10:00", "2020-01-03 09:00", "2020-01-03 09:00", "2020-01-03 10:00", "2020-01-03 10:00"]),
                           "side": ["buy", "sell", "writeoff", "buy", "buy"],
                           "quantity": [10, 10, 10, 10, 10], "price": [100, 110, 0, 100, 100], "fee": [1, 1.1, 0, 1, 1]})
    result = cash_history(orders, 10000)
    assert result.loc[0, "cash_after_order"] == 8999
    assert np.isclose(result.loc[3, "cash_before_opening_entries"], 10097.9)
    assert result.loc[3, "cash_before_opening_entries"] == result.loc[4, "cash_before_opening_entries"]
    assert result.loc[3, "cash_before_order"] != result.loc[4, "cash_before_order"]


def write_annual_fixture(root):
    folder = root / "years/2020"
    folder.mkdir(parents=True)
    initial = 10_000_000
    fee = .001
    # All opening entries share a cash/5 snapshot. No duplicate writeoff loss.
    quantities = [int(initial / 5 / (100 * (1 + fee))), int(initial / 5 / (200 * (1 + fee)))]
    orders = pd.DataFrame([
        {"date": "2020-01-02 10:00", "code": "000001", "side": "buy", "quantity": quantities[0], "price": 100., "fee": quantities[0]*100*fee, "reason": "top_n"},
        {"date": "2020-01-02 10:00", "code": "00001A", "side": "buy", "quantity": quantities[1], "price": 200., "fee": quantities[1]*200*fee, "reason": "top_n"},
        {"date": "2020-01-03 09:00", "code": "000001", "side": "writeoff", "quantity": quantities[0], "price": 0., "fee": 0., "reason": "delisting_zero_recovery"},
    ])
    orders.to_csv(folder / "orders.csv", index=False)
    rows = []
    for code, size, entry_price, exit_price, status in [
        ("000001", quantities[0], 100., 0., "Closed"), ("00001A", quantities[1], 200., 230., "Open"),
    ]:
        pnl = size * (exit_price - entry_price) - size * entry_price * fee
        rows.append({"Column": code, "Size": size, "Entry Timestamp": "2020-01-02 10:00",
                     "Avg Entry Price": entry_price, "Entry Fees": size*entry_price*fee,
                     "Exit Timestamp": "2020-01-03 09:00" if status == "Closed" else "2020-01-06 16:00",
                     "Avg Exit Price": exit_price, "Exit Fees": 0., "PnL": pnl, "Status": status})
    pd.DataFrame(rows).to_csv(folder / "trades.csv", index=False)
    report = {"exclusions": [], "writeoffs": [{"code": "000001"}],
              "open_positions": [{"code": "00001A", "entry_date": "2020-01-02", "quantity": quantities[1],
                                  "valuation_price": 230., "unrealized_pnl_before_exit_fee": rows[1]["PnL"]}]}
    (folder / "execution_report.json").write_text(json.dumps(report))
    return initial


def test_open_year_end_and_delisting_accounting_and_daily_marks(tmp_path):
    initial = write_annual_fixture(tmp_path)
    ledger, orders, _ = annual_ledger(tmp_path, 2020, initial)
    assert ledger.Code.tolist() == ["000001", "00001A"]
    assert ledger.exit_reason.tolist() == ["delisting_zero_recovery", "year_end_mark"]
    days = pd.to_datetime(["2020-01-02", "2020-01-03", "2020-01-06"])
    prices = pd.DataFrame({"Date": [days[0], *days], "Code": ["000001", "00001A", "00001A", "00001A"],
                           "Close": [100., 205., 210., 230.]})
    daily = daily_stock_pnl(ledger, prices, days)
    assert np.isclose(daily.iloc[-1].sum(), ledger.pnl.sum())
    assert daily.loc[days[1], "000001"] == ledger.loc[0, "pnl"]
    cash = orders.cash_after_order.iloc[-1]
    assert np.isclose(initial + daily.iloc[-1].sum(), cash + ledger.loc[1, "quantity"] * 230)
    assert np.isclose(ledger.invested.iloc[0], -ledger.pnl.iloc[0])
    b = ledger.copy()
    b.loc[1, ["quantity", "pnl", "invested"]] *= 2
    matched = match_trades(ledger, b, 20)
    assert matched.same_path.all()
    assert np.isclose(matched.contribution.sum(), b.pnl.sum() - ledger.pnl.sum())
    assert np.isclose(matched.quantity_contribution_A_reference.sum(), matched.contribution.sum())
    assert np.isclose(matched.path_contribution_A_reference.sum(), 0)
    unique = match_trades(ledger.iloc[:1], ledger.iloc[1:], 20)
    assert set(unique.group) == {"A_only", "B_only"}
    assert np.isclose(unique.contribution.sum(), ledger.pnl.iloc[1] - ledger.pnl.iloc[0])


def test_paired_blocks_are_deterministic_with_undefined_days():
    days = pd.bdate_range("2020-01-02", periods=100).append(pd.bdate_range("2021-01-04", periods=100))
    daily = pd.DataFrame({"roc_auc_delta": np.r_[np.full(100, .1), np.full(100, -.2)],
                          "brier_score_delta": -.01, "ic_mean_delta": .02}, index=days)
    daily.iloc[3, 0] = np.nan
    intervals = block_intervals(daily, 20)
    pd.testing.assert_frame_equal(intervals, block_intervals(copy.deepcopy(daily), 20))
    auc = intervals.loc[intervals.metric.eq("roc_auc")]
    assert np.allclose(auc.loc[auc.year.eq(2020), "ci95_low"], .1)
    assert np.allclose(auc.loc[auc.year.eq(2021), "ci95_high"], -.2)
    assert set(intervals.block_days) == {20, 60}
    assert intervals.repetitions.eq(2000).all()
    assert intervals.estimand.eq("mean_daily_B_minus_A").all()


def test_annual_artifact_verification_handles_nan_and_detects_changed_order(tmp_path):
    aggregates = {name: [] for name in ("orders.csv", "trades.csv", "daily_returns.csv")}
    metrics = []
    for year in range(2019, 2026):
        folder = tmp_path / "years" / str(year)
        folder.mkdir(parents=True)
        frames = {
            "orders.csv": pd.DataFrame({"code": ["000001", "00001A"], "quantity": [5., 10.]}),
            "trades.csv": pd.DataFrame({"Column": ["000001", "00001A"], "PnL": [100., 200.]}),
            "daily_returns.csv": pd.DataFrame({"Date": [f"{year}-01-02"], "Portfolio": [.01]}),
        }
        for name, frame in frames.items():
            frame.to_csv(folder / name, index=False)
            aggregate = frame.assign(year=year).copy()
            for column in ("code", "Column"):
                if column in aggregate:
                    aggregate[column] = aggregate[column].map(lambda c: str(int(c)) if c.isdigit() else c)
            aggregates[name].append(aggregate)
        annual = {"average_holding_days": np.nan, "final_equity": 10000300.}
        (folder / "backtest_metrics.json").write_text(json.dumps(annual))
        metrics.append(dict(year=year, **annual))
    for name, frames in aggregates.items():
        pd.concat(frames).to_csv(tmp_path / name, index=False)
    (tmp_path / "backtest_metrics.json").write_text(json.dumps({"years": metrics}))
    verify_annual_artifacts(tmp_path)
    (tmp_path / "years/2020/orders.csv").write_text("code,quantity\n000001,6\n00001A,10\n")
    with pytest.raises(ValueError, match="Annual/hashed aggregate mismatch"):
        verify_annual_artifacts(tmp_path)


def test_saved_hash_corruption_stops_before_attribution(tmp_path):
    source = tmp_path / "predictions.parquet"
    source.write_bytes(b"original")
    status = {"status": "complete", "run_id": "same", "completed": {
        "h5_A:train": {str(source): sha256(source)}, "h5_A:ml": {}, "h5_A:backtest": {},
    }}
    (tmp_path / "status.json").write_text(json.dumps(status))
    (tmp_path / "prepared.json").write_text(json.dumps({"run_id": "same"}))
    source.write_bytes(b"changed")
    with pytest.raises(ValueError, match="Saved hash mismatch"):
        load_suite(tmp_path, tmp_path)
