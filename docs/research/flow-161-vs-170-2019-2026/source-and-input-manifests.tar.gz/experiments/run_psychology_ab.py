"""Run paired flow/psychology experiments through the canonical chart pipeline."""

from __future__ import annotations

import argparse
import copy
import fcntl
import json
import os
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import pandas as pd
import yaml
from experiments.config import chart_path, load_dataset_config, load_experiment_config, read_yaml
from experiments.dataset.pipeline import preprocess_dataset, validate_processed_inputs
from experiments.experiment_utils import (
    model_cache_dir,
    predictions_cache_path,
    resolve_splits,
    result_dir,
)
from experiments.features.local_panel import prepare_local_panel
from experiments.features.psychology import TREATMENT_FEATURES
from shared.features.columns import BASE_FEATURES, FLOW_FEATURES
from shared.io import atomic_json, identity, sha256
from shared.settings import processing_contract

DEFAULT_CONFIG = "experiments/configs/psychology_ab_2019_2025.yaml"


def snapshot_dataset(source, dataset_config):
    """Copy verified local inputs; never collect or overwrite the source dataset."""
    config = load_dataset_config(dataset_config)
    target = Path(config["root"])
    source = Path(source).resolve()
    if target == source or source in target.parents or target in source.parents:
        raise ValueError("Snapshot must use a separate dataset root")
    original = json.loads((source / "dataset_manifest.json").read_text())
    if not original.get("prices_complete") or not original.get("raw_files"):
        raise ValueError("Source price collection is incomplete")
    if pd.Timestamp(original["end_date"]) < pd.Timestamp(config["collection"]["end_date"]):
        raise ValueError("Source does not cover the configured frozen end date")
    files = {f"raw/{name}": digest for name, digest in original["raw_files"].items()}
    for name in original["raw_files"]:
        if Path(name).name != name:
            raise ValueError("Invalid source raw filename")
    for name in ("calendar.json", "ticker_metadata.csv", "benchmarks/KOSPI.parquet"):
        files[name] = sha256(source / name)
    provenance = {"source": str(source), "source_manifest_sha256": sha256(source / "dataset_manifest.json"),
                  "files": files, "config": config}
    provenance_path = target / "snapshot_source.json"
    if provenance_path.exists() and json.loads(provenance_path.read_text()) != provenance:
        raise ValueError("Snapshot inputs changed; choose a new dataset root")
    atomic_json(provenance_path, provenance)
    for index, (name, digest) in enumerate(files.items(), 1):
        destination = target / name
        if destination.exists():
            if sha256(destination) != digest:
                raise ValueError(f"Snapshot input modified: {destination}")
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary = destination.with_suffix(destination.suffix + ".tmp")
            shutil.copyfile(source / name, temporary)
            if sha256(temporary) != digest:
                raise ValueError(f"Source input changed: {name}")
            temporary.replace(destination)
        if index % 100 == 0:
            print(f"Snapshot inputs: {index}/{len(files)}", flush=True)
    manifest = dict(original, config=config, dataset_id=config["dataset_id"],
                    source_manifest_sha256=provenance["source_manifest_sha256"])
    path = target / "dataset_manifest.json"
    if path.exists() and json.loads(path.read_text()) != manifest:
        raise ValueError("Snapshot manifest changed")
    atomic_json(path, manifest)
    if (target / "processed_manifest.json").exists():
        validate_processed_inputs(config)
    else:
        print("Rebuilding processed inputs with the current shared builder", flush=True)
        preprocess_dataset(dataset_config)
    return config


def write_config(path, config):
    text = yaml.safe_dump(config, sort_keys=False, allow_unicode=True)
    if path.exists() and path.read_text() != text:
        raise ValueError(f"Generated config changed: {path}; choose a new output_dir")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def prepare_configs(plan, output):
    """Build B first and use its eligible keys for both A horizons."""
    paths = {}
    for horizon in (5, 20):
        template = read_yaml(plan["templates"][f"h{horizon}"])
        template["dataset"] = str(chart_path(plan["dataset"]))
        template["data"] = copy.deepcopy(plan["data"])
        template["model"]["params"]["n_jobs"] = plan["n_jobs"]
        template["training"]["skip_validation"] = True
        template["evaluation"]["benchmark_file"] = str(
            Path(load_dataset_config(plan["dataset"])["root"]) / "benchmarks/KOSPI.parquet"
        )
        for variant in ("B", "A"):
            config = copy.deepcopy(template)
            config["experiment_name"] = f"psychology_ab_2019_2025_h{horizon}_{variant}"
            config["features"] = {"groups": ["base", "flow"] + (["psychology"] if variant == "B" else [])}
            if variant == "A":
                b_config = load_experiment_config(paths[(horizon, "B")])
                config["features"]["matched_sample_file"] = str(
                    Path(b_config["features"]["materialized_dir"]) / "sample_keys.parquet"
                )
            path = output / "configs" / f"h{horizon}_{variant}.yaml"
            write_config(path, config)
            paths[(horizon, variant)] = path
            resolved = load_experiment_config(path)
            print(f"Prepare H{horizon} {variant}: {len(resolved['feature_columns'])} inputs", flush=True)
            prepare_local_panel(resolved)
    return paths


def verify_paired_features(a_config, b_config):
    common = list(BASE_FEATURES) + list(FLOW_FEATURES)
    if a_config["feature_columns"] != common or b_config["feature_columns"] != common + list(TREATMENT_FEATURES):
        raise ValueError("Expected A=170 and B=174 canonical features")
    for section in ("data", "labels", "model", "training", "strategy", "backtest", "evaluation"):
        left, right = copy.deepcopy(a_config[section]), copy.deepcopy(b_config[section])
        if section == "data":
            left.pop("price_dir", None)
            right.pop("price_dir", None)
        if left != right:
            raise ValueError(f"A/B settings differ: {section}")
    a_root = Path(a_config["features"]["materialized_dir"])
    b_root = Path(b_config["features"]["materialized_dir"])
    a_manifest = json.loads((a_root / "feature_manifest.json").read_text())
    b_manifest = json.loads((b_root / "feature_manifest.json").read_text())
    if set(a_manifest["file_hashes"]) != set(b_manifest["file_hashes"]):
        raise ValueError("A/B stock files differ")
    keys = ["Date", "Code"]
    columns = keys + ["Open", "High", "Low", "Close", "Trading_Halt", "Sigma", "SampleEligible"] + common
    count = 0
    for name in a_manifest["file_hashes"]:
        a = pd.read_parquet(a_root / name, columns=columns)
        b = pd.read_parquet(b_root / name, columns=columns)
        if not a.equals(b):
            raise ValueError(f"A/B full price-path keys, masks or common inputs differ: {name}")
        count += int(a.SampleEligible.sum())
    a_keys = pd.read_parquet(a_root / "sample_keys.parquet")
    b_keys = pd.read_parquet(b_root / "sample_keys.parquet")
    if not a_keys.equals(b_keys) or len(a_keys) != count:
        raise ValueError("A/B eligible sample keys differ")
    return {"eligible_rows": count, "stock_files": len(a_manifest["file_hashes"]),
            "sample_keys_sha256": sha256(a_root / "sample_keys.parquet"),
            "common_inputs_equal": True}


def write_comparison(configs, output):
    rows = []
    for horizon in (5, 20):
        frames = {}
        histories = {}
        for variant in ("A", "B"):
            folder = Path(result_dir(configs[(horizon, variant)], __file__))
            ml = pd.read_csv(folder / "model_metrics_by_fold.csv")
            splits = resolve_splits(configs[(horizon, variant)])
            ml["year"] = ml.fold_id.map({s["fold_id"]: pd.Timestamp(s["test_start"]).year for s in splits})
            bt = pd.read_csv(folder / "backtest_metrics_by_year.csv")
            frames[variant] = ml.merge(bt, on="year", validate="one_to_one", suffixes=("", "_backtest"))
            histories[variant] = pd.read_parquet(folder / "oos_history.parquet",
                                                columns=["Date", "Code", "Y_Label", "label_observed", "fold_id"])
        if not histories["A"].equals(histories["B"]):
            raise ValueError(f"H{horizon} A/B prediction keys or outcome labels differ")
        paired = frames["A"].merge(frames["B"], on="year", validate="one_to_one", suffixes=("_A", "_B"))
        expected_years = [pd.Timestamp(s["test_start"]).year for s in splits]
        if paired.year.tolist() != expected_years or not paired.sample_count_A.equals(paired.sample_count_B):
            raise ValueError(f"H{horizon} A/B years or evaluated row counts differ")
        metrics = ["roc_auc", "pr_auc", "balanced_accuracy", "brier_score", "ic_mean",
                   "total_return", "sharpe_ratio", "max_drawdown", "number_of_trades"]
        for record in paired.to_dict("records"):
            row = {"horizon": horizon, "year": record["year"], "sample_count": record["sample_count_A"]}
            for metric in metrics:
                a, b = record[f"{metric}_A"], record[f"{metric}_B"]
                row.update({f"{metric}_A": a, f"{metric}_B": b, f"{metric}_B_minus_A": b - a})
            rows.append(row)
    comparison = pd.DataFrame(rows)
    comparison.to_csv(output / "comparison_by_year.csv", index=False)
    means = comparison.groupby("horizon").mean(numeric_only=True).drop(columns=["year", "sample_count"])
    means.to_csv(output / "comparison_mean.csv")
    lines = ["# 수급 기준 시장 심리 A/B 결과", "", f"평가 연도 {expected_years}. A=170개, B=174개 입력.",
             "학습·예측 대상과 관측 완료 정답을 A/B 공통으로 검증했다.", "",
             "| 기간 | 평균 ROC-AUC A | 평균 ROC-AUC B | B-A | 개선 연도 |", "| --- | ---: | ---: | ---: | ---: |"]
    for horizon, record in means.iterrows():
        wins = int(comparison.loc[comparison.horizon.eq(horizon), "roc_auc_B_minus_A"].gt(0).sum())
        lines.append(f"| H{horizon} | {record.roc_auc_A:.6f} | {record.roc_auc_B:.6f} | {record.roc_auc_B_minus_A:+.6f} | {wins}/{len(expected_years)} |")
    lines += ["", "평균은 연도별 지표의 단순평균이다. 매년 자금을 초기화하므로 연속 운용 CAGR이 아니다.",
              "Brier는 낮을수록 좋다. Rank IC는 0/1/2 라벨과의 순위 상관이다.",
              "통계적 유의성 검정은 하지 않았다. 현재 수정가격·과거 구성종목·체결 가정의 한계가 남는다.",
              "결론의 범위는 수급·심리 입력이 갖춰진 공통 표본이다. 기존 기간을 손대지 않은 holdout으로 부르지 않는다.",
              "", "연도별 전체 지표: comparison_by_year.csv. 평균: comparison_mean.csv."]
    (output / "REPORT.md").write_text("\n".join(lines) + "\n")


def suite_identity(plan):
    source = chart_path(plan["source_dataset_root"])
    root = Path(__file__).parent
    files = [Path(__file__), root / "config.py", root / "experiment_utils.py", root / "train.py",
             root / "run_ml_evaluation.py", root / "run_backtest.py"]
    for folder in ("features", "train_src", "evaluation", "backtest"):
        files.extend(sorted((root / folder).rglob("*.py")))
    files.extend(chart_path(path) for path in plan["templates"].values())
    files.append(chart_path(plan["dataset"]))
    files.extend(source / name for name in ("dataset_manifest.json", "calendar.json", "ticker_metadata.csv", "benchmarks/KOSPI.parquet"))
    return identity({"plan": plan, "processing_contract": processing_contract(),
                     "files": {str(path): sha256(path) for path in files}})


def run(plan, output, prepare_only=False):
    output.mkdir(parents=True, exist_ok=True)
    with (output / "run.lock").open("w") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("This A/B suite is already running") from exc
        run_id = suite_identity(plan)
        status_path = output / "status.json"
        status = json.loads(status_path.read_text()) if status_path.exists() else {"run_id": run_id, "completed": {}}
        if status["run_id"] != run_id:
            raise ValueError("Suite code/config/source changed; choose a new output_dir")
        status.pop("error", None)
        status.update(status="running", pid=os.getpid(), started_at=datetime.now(UTC).isoformat())
        atomic_json(status_path, status)
        try:
            status["stage"] = "prepare"
            atomic_json(status_path, status)
            snapshot_dataset(chart_path(plan["source_dataset_root"]), plan["dataset"])
            paths = prepare_configs(plan, output)
            configs = {key: load_experiment_config(path) for key, path in paths.items()}
            paired = {f"h{h}": verify_paired_features(configs[(h, "A")], configs[(h, "B")]) for h in (5, 20)}
            atomic_json(output / "prepared.json", {"run_id": run_id, "paired_features": paired,
                        "configs": {f"h{h}_{v}": str(p) for (h, v), p in paths.items()},
                        "splits": resolve_splits(configs[(5, "A")])})
            if prepare_only:
                status.update(status="prepared", stage="ready")
                atomic_json(status_path, status)
                print(f"Ready: {output / 'prepared.json'}", flush=True)
                return
            for horizon in (5, 20):
                for variant in ("A", "B"):
                    config = configs[(horizon, variant)]
                    folder = Path(result_dir(config, __file__))
                    for phase, module in (("train", "experiments.train"), ("ml", "experiments.run_ml_evaluation"),
                                          ("backtest", "experiments.run_backtest")):
                        task = f"h{horizon}_{variant}:{phase}"
                        status["stage"] = task
                        atomic_json(status_path, status)
                        previous = status["completed"].get(task)
                        if previous:
                            if any(not Path(p).is_file() or sha256(p) != digest for p, digest in previous.items()):
                                raise ValueError(f"Completed artifacts modified: {task}")
                            print(f"Resume: {task} already completed", flush=True)
                            continue
                        print(f"Starting {task}; log: {output / 'run.log'}", flush=True)
                        with (output / "run.log").open("a") as log:
                            subprocess.run([sys.executable, "-u", "-m", module, "--config", str(paths[(horizon, variant)])],
                                           cwd=Path(__file__).resolve().parents[1], stdout=log,
                                           stderr=subprocess.STDOUT, check=True)
                        if phase == "train":
                            prediction = Path(predictions_cache_path(config, resolve_splits(config), __file__))
                            artifacts = [prediction, Path(str(prediction) + ".manifest.json")]
                            model_root = Path(model_cache_dir(__file__))
                            for index in range(len(resolve_splits(config))):
                                name = f"{json.loads(artifacts[1].read_text())['predictions_hash']}_fold{index}_model.txt"
                                artifacts.extend([model_root / name, model_root / (name + ".manifest.json")])
                        elif phase == "ml":
                            artifacts = [folder / name for name in ("ml_metrics_summary.json", "model_metrics_by_fold.csv", "oos_history.parquet", "oos_history.manifest.json")]
                        else:
                            artifacts = [folder / name for name in ("backtest_metrics.json", "backtest_metrics_by_year.csv", "orders.csv", "trades.csv", "daily_returns.csv")]
                        status["completed"][task] = {str(p): sha256(p) for p in artifacts}
                        atomic_json(status_path, status)
            status["stage"] = "comparison"
            atomic_json(status_path, status)
            write_comparison(configs, output)
            status.update(status="complete", stage="done", finished_at=datetime.now(UTC).isoformat())
            atomic_json(status_path, status)
            print(f"Complete: {output / 'REPORT.md'}", flush=True)
        except (Exception, KeyboardInterrupt) as exc:
            status.update(status="interrupted" if isinstance(exc, KeyboardInterrupt) else "failed", error=str(exc))
            atomic_json(status_path, status)
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=DEFAULT_CONFIG)
    parser.add_argument("--prepare-only", action="store_true", help="Verify/build inputs without training")
    parser.add_argument("--background", action="store_true", help="Detach from terminal; write run.log and status.json")
    args = parser.parse_args()
    config_path = chart_path(args.config)
    plan = read_yaml(config_path)
    output = chart_path(plan["output_dir"])
    if args.background:
        if args.prepare_only:
            parser.error("--background cannot combine with --prepare-only")
        output.mkdir(parents=True, exist_ok=True)
        with (output / "run.log").open("a") as log:
            process = subprocess.Popen([sys.executable, "-u", "-m", "experiments.run_psychology_ab", "--config", str(config_path)],
                                       cwd=Path(__file__).resolve().parents[1], stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        print(f"Started PID {process.pid}. Log: {output / 'run.log'}\nStatus: {output / 'status.json'}")
        return
    run(plan, output, args.prepare_only)


if __name__ == "__main__":
    main()
