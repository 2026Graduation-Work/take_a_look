"""Explain saved psychology A/B results without training or changing inputs."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
import pandas as pd
from experiments.config import chart_path, load_experiment_config
from experiments.evaluation.backtest_metrics import calculate_trading_metrics
from experiments.evaluation.metrics import (
    calculate_classification_metrics,
    calculate_rank_ic,
    daily_rank_ic,
)
from experiments.experiment_utils import build_fold_alignment, resolve_splits
from experiments.features.psychology import (
    TREATMENT_FEATURES,
    PsychologyFeatureConfig,
    PsychologyInputError,
    build_psychology_features,
)
from experiments.run_psychology_ab import verify_paired_features
from experiments.train_src.loaders import load_parquet_data
from experiments.train_src.swing_strategy import SwingStrategy
from shared.io import atomic_json, atomic_parquet, sha256

KEYS = ["Date", "Code"]
TRADE_KEYS = ["year", "Code", "entry_date"]
METRICS = ["roc_auc", "pr_auc", "brier_score", "ic_mean"]
BINS = ["[0,0.50)", "[0.50,0.60)", "[0.60,0.65)", "[0.65,0.70)", "[0.70,1]"]


def read_json(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equal_number(actual, expected, name, atol=1e-10):
    expected = np.nan if expected is None else float(expected)
    require(np.isclose(actual, expected, rtol=0, atol=atol, equal_nan=True),
            f"Reproduction mismatch {name}: {actual} != {expected}")


def read_codes(path):
    """Read original annual files; never infer numeric ticker types."""
    try:
        frame = pd.read_csv(path, dtype={"code": str, "Column": str})
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    return frame


def verify_annual_artifacts(root):
    """Annual files must agree with the hash-verified aggregate artifacts."""
    for filename in ("orders.csv", "trades.csv", "daily_returns.csv"):
        aggregate = read_codes(root / filename)
        for year in range(2019, 2026):
            saved = aggregate.loc[aggregate.year.eq(year)].drop(columns="year").reset_index(drop=True)
            annual = read_codes(root / "years" / str(year) / filename)
            if annual.empty and saved.empty:
                continue
            for column in set(saved) - set(annual):
                require(saved[column].isna().all(), f"Unexpected aggregate column: {filename}/{column}")
            saved = saved.reindex(columns=annual.columns)
            for column in ("code", "Column"):
                if column in saved:
                    # The original concatenation dropped numeric leading zeros.
                    saved[column] = saved[column].map(lambda c: c.zfill(6) if c.isdigit() else c)
            try:
                pd.testing.assert_frame_equal(saved, annual.reset_index(drop=True), check_dtype=False,
                                              rtol=0, atol=1e-8)
            except AssertionError as exc:
                raise ValueError(f"Annual/hashed aggregate mismatch: {filename}/{year}") from exc
    saved_metrics = read_json(root / "backtest_metrics.json")["years"]
    for row in saved_metrics:
        annual = read_json(root / "years" / str(row["year"]) / "backtest_metrics.json")
        # Original metrics contain NaN durations; NaN != NaN in Python.
        require(json.dumps({key: row[key] for key in annual}, sort_keys=True)
                == json.dumps(annual, sort_keys=True), "Annual/aggregate metrics mismatch")


def paired_history(a, b):
    a, b = [frame.sort_values(KEYS).reset_index(drop=True) for frame in (a, b)]
    for frame in (a, b):
        require(not frame.duplicated(KEYS).any(), "Duplicate OOS Date/Code")
        require(frame.Code.map(lambda x: isinstance(x, str)).all(), "Ticker must be a string")
        require(frame.label_observed.equals(frame.Y_Label.notna()), "Label observation mask mismatch")
        require(frame.Y_Label.dropna().isin([0, 1, 2]).all(), "Invalid label")
        require(np.isfinite(frame[["Prob", "prob_up"]]).all().all(), "Non-finite score")
        require(frame.prob_up.between(0, 1).all(), "Score outside [0,1]")
        require(frame.Prob.equals(frame.prob_up), "Evaluation and execution scores differ")
    columns = KEYS + ["fold_id", "Y_Label", "label_observed"]
    require(a[columns].equals(b[columns]), "A/B keys, folds, labels or observation masks differ")
    return a[columns].assign(score_A=a.prob_up, score_B=b.prob_up,
                             score_delta=b.prob_up - a.prob_up)


def load_suite(suite, out):
    status = read_json(suite / "status.json")
    prepared = read_json(suite / "prepared.json")
    require(status.get("status") == "complete", "Suite is not complete")
    require(status["run_id"] == prepared["run_id"], "Prepared/status identities differ")
    artifacts = []
    runs = {}
    for horizon in (5, 20):
        for variant in ("A", "B"):
            key = f"h{horizon}_{variant}"
            for phase in ("train", "ml", "backtest"):
                files = status["completed"][f"{key}:{phase}"]
                for name, digest in files.items():
                    path = Path(name)
                    require(path.is_file() and sha256(path) == digest, f"Saved hash mismatch: {path}")
                    artifacts.append({"task": f"{key}:{phase}", "path": str(path), "sha256": digest})
            train = status["completed"][f"{key}:train"]
            prediction = next(Path(p) for p in train if p.endswith("_predictions.parquet"))
            saved = read_json(str(prediction) + ".manifest.json")["config"]
            config = load_experiment_config(prepared["configs"][key])
            require(config == saved, f"Saved/current configuration differs: {key}")
            require(config["backtest"]["capital_mode"] == "independent_year", "Annual reset required")
            require(config["backtest"]["initial_cash"] == 10_000_000, "Expected 10 million initial cash")
            require(config["strategy"]["prob_threshold"] == .65 and config["strategy"]["top_n"] == 5,
                    "Expected threshold .65 and daily top 5")
            ml = status["completed"][f"{key}:ml"]
            history_path = next(Path(p) for p in ml if p.endswith("oos_history.parquet"))
            history = pd.read_parquet(history_path)
            predictions = pd.read_parquet(prediction).sort_values(KEYS).reset_index(drop=True)
            require(history.sort_values(KEYS).reset_index(drop=True)[predictions.columns].equals(predictions),
                    f"History/cache predictions differ: {key}")
            splits = resolve_splits(config)
            _, alignment = build_fold_alignment(predictions, splits)
            require(alignment["is_exact_fold_match"], f"Fold alignment differs: {key}")
            require([pd.Timestamp(s["test_start"]).year for s in splits] == list(range(2019, 2026)),
                    "Expected seven annual test folds 2019..2025")
            verify_annual_artifacts(history_path.parent)
            runs[(horizon, variant)] = {"config": config, "history": history,
                                       "root": history_path.parent, "models": sorted(
                                           Path(p) for p in train if p.endswith("_model.txt"))}
            print(f"Verified hashes/config/predictions: {key}", flush=True)
    pairs = {}
    for horizon in (5, 20):
        a, b = (runs[(horizon, v)] for v in ("A", "B"))
        for section in ("dataset", "labels", "model", "training", "strategy", "backtest", "evaluation"):
            require(a["config"][section] == b["config"][section], f"A/B {section} differs")
        require(resolve_splits(a["config"]) == resolve_splits(b["config"]), "A/B splits differ")
        pairs[horizon] = paired_history(a["history"], b["history"])
    pd.DataFrame(artifacts).to_csv(out / "input_hashes.csv", index=False)
    return runs, pairs


def reproduce_metrics(runs, out):
    rows = []
    for (horizon, variant), run in runs.items():
        history = run["history"]
        labeled = history.loc[history.label_observed]
        saved_years = pd.read_csv(run["root"] / "model_metrics_by_fold.csv").set_index("fold_id")
        saved_all = read_json(run["root"] / "ml_metrics_summary.json")
        for year, frame in [(0, labeled), *labeled.groupby(labeled.Date.dt.year)]:
            metrics = calculate_classification_metrics(frame.Y_Label, frame.Prob)
            metrics.update(calculate_rank_ic(frame))
            saved = saved_all if year == 0 else saved_years.loc[frame.fold_id.iloc[0]]
            require(len(frame) == saved["ml_sample_count" if year == 0 else "sample_count"],
                    f"Observed sample count differs: {horizon}/{variant}/{year}")
            for metric in METRICS:
                key = ("ic_ic_mean" if metric == "ic_mean" else f"ml_{metric}") if year == 0 else metric
                equal_number(metrics[metric], saved[key], f"H{horizon}/{variant}/{year}/{metric}")
            rows.append({"horizon": horizon, "variant": variant, "year": year,
                         "sample_count": len(frame), **{m: metrics[m] for m in METRICS}})
        print(f"Reproduced annual/pooled ML metrics: H{horizon} {variant}", flush=True)
    result = pd.DataFrame(rows)
    result.to_csv(out / "prediction_metrics.csv", index=False)
    return result


def score_bin(scores):
    return pd.Series(np.asarray(BINS)[np.searchsorted([.50, .60, .65, .70], scores, side="right")],
                     index=scores.index)


def score_diagnostics(pair, horizon):
    rows = []
    transitions = pair.assign(year=pair.Date.dt.year, bin_A=score_bin(pair.score_A),
                              bin_B=score_bin(pair.score_B))
    for year, frame in transitions.groupby("year"):
        for variant in ("A", "B"):
            for name in BINS:
                group = frame.loc[frame[f"bin_{variant}"].eq(name)]
                observed = group.loc[group.label_observed]
                rows.append({"horizon": horizon, "year": year, "variant": variant, "bin": name,
                             "prediction_rows": len(group), "observed_rows": len(observed),
                             "mean_score": group[f"score_{variant}"].mean(),
                             "actual_up_label_ratio": observed.Y_Label.eq(2).mean()})
    counts = transitions.groupby(["year", "bin_A", "bin_B"]).agg(
        prediction_rows=("Code", "size"), observed_rows=("label_observed", "sum")
    ).reset_index().assign(horizon=horizon)
    return pd.DataFrame(rows), counts


def candidate_signals(config, predictions, prices):
    """Keep canonical sorting, eligibility and lag rules for every OOS row."""
    entries, _ = SwingStrategy(config).generate_signals(predictions, prices)
    raw_config = copy.deepcopy(config)
    raw_config["backtest"]["signal_lag_days"] = 0
    raw, _ = SwingStrategy(raw_config).generate_signals(predictions, prices)
    days, codes = entries.index, entries.columns
    market_columns = KEYS + ["Open", "Trading_Halt"]
    if "UniverseEligible" in prices:
        market_columns.append("UniverseEligible")
    p = predictions[KEYS + ["prob_up"]].merge(
        prices[market_columns], on=KEYS, how="left", validate="one_to_one"
    )
    p["threshold_pass"] = p.prob_up.ge(config["strategy"]["prob_threshold"])
    p["signal_eligible"] = p.Open.notna() & p.Open.gt(1) & p.Trading_Halt.eq(0)
    if "UniverseEligible" in p:
        p["signal_eligible"] &= p.UniverseEligible.fillna(False)
    # pivot sorts ticker columns; method='first' breaks ties in that exact order.
    p = p.sort_values(KEYS).reset_index(drop=True)
    p["rank"] = p.prob_up.where(p.threshold_pass & p.signal_eligible).groupby(p.Date).rank(
        method="first", ascending=False
    )
    i, j = days.get_indexer(p.Date), codes.get_indexer(p.Code)
    require((i >= 0).all() and (j >= 0).all(), "Prediction outside signal matrices")
    p["selected"] = raw.to_numpy()[i, j]
    require(p.selected.equals(p["rank"].le(config["strategy"]["top_n"])), "Canonical top-N mismatch")
    target = i + config["backtest"]["signal_lag_days"]
    within = target < len(days)
    p["entry_date"] = pd.NaT
    p.loc[within, "entry_date"] = days[target[within]].to_numpy()
    p["entry_allowed"] = False
    p.loc[within, "entry_allowed"] = entries.to_numpy()[target[within], j[within]]
    return p.drop(columns=["Open", "Trading_Halt", "UniverseEligible"], errors="ignore")


def cash_history(orders, initial_cash):
    if orders.empty:
        return orders
    orders = orders.sort_values("date", kind="stable").copy()
    cash_delta = np.where(orders.side.eq("buy"),
                          -orders.quantity * orders.price - orders.fee,
                          np.where(orders.side.eq("sell"), orders.quantity * orders.price - orders.fee, 0))
    orders["cash_before_order"] = initial_cash + np.r_[0, np.cumsum(cash_delta)[:-1]]
    orders["cash_after_order"] = initial_cash + np.cumsum(cash_delta)
    for _day, group in orders.groupby(orders.date.dt.normalize()):
        opening = group.loc[group.date.dt.hour.le(9)]
        snapshot = opening.cash_after_order.iloc[-1] if len(opening) else group.cash_before_order.iloc[0]
        orders.loc[group.index, "cash_before_opening_entries"] = snapshot
    return orders


def annual_ledger(root, year, initial_cash):
    """One PnL row per buy, including open marks and zero-recovery delistings."""
    folder = root / "years" / str(year)
    trades, orders = read_codes(folder / "trades.csv"), read_codes(folder / "orders.csv")
    report = read_json(folder / "execution_report.json")
    if orders.empty:
        require(trades.empty, "Trades without orders")
        return pd.DataFrame(), orders, report
    orders["date"] = pd.to_datetime(orders.date)
    orders = cash_history(orders, initial_cash)
    buys = orders.loc[orders.side.eq("buy")]
    require(len(buys) == len(trades), "Buy/trade counts differ")
    rows = []
    for trade in trades.to_dict("records"):
        code, entry = trade["Column"], pd.Timestamp(trade["Entry Timestamp"])
        buy = buys.loc[buys.code.eq(code) & buys.date.eq(entry)]
        require(len(buy) == 1, f"Missing/duplicate buy: {code}/{entry}")
        buy = buy.iloc[0]
        quantity, cost = buy.quantity, buy.quantity * buy.price + buy.fee
        require(quantity == trade["Size"], "Buy/trade quantity mismatch")
        equal_number(buy.price, trade["Avg Entry Price"], "entry price", atol=1e-7)
        equal_number(buy.fee, trade["Entry Fees"], "entry fee", atol=1e-7)
        exit_time = pd.Timestamp(trade["Exit Timestamp"])
        if trade["Status"] == "Closed":
            sell = orders.loc[orders.code.eq(code) & orders.date.eq(exit_time)
                              & orders.side.isin(["sell", "writeoff"])]
            require(len(sell) == 1, f"Missing/duplicate exit: {code}/{entry}")
            sell = sell.iloc[0]
            require(sell.quantity == quantity, "Exit quantity mismatch")
            pnl = quantity * sell.price - sell.fee - cost
            reason, exit_price, exit_fee = sell.reason, sell.price, sell.fee
        else:
            positions = [p for p in report["open_positions"]
                         if p["code"] == code and pd.Timestamp(p["entry_date"]) == entry.normalize()]
            require(len(positions) == 1, f"Open position missing: {code}/{entry}")
            position = positions[0]
            require(position["quantity"] == quantity, "Open quantity mismatch")
            exit_price, exit_fee = position["valuation_price"], 0
            pnl = quantity * exit_price - cost
            equal_number(pnl, position["unrealized_pnl_before_exit_fee"], "open PnL", atol=1e-6)
            reason = "year_end_mark"
        equal_number(pnl, trade["PnL"], "trade PnL", atol=1e-6)
        rows.append({"year": year, "Code": code, "entry_date": entry.normalize(), "entry_time": entry,
                     "quantity": quantity, "entry_price": buy.price, "entry_fee": buy.fee,
                     "invested": cost, "exit_time": exit_time, "exit_price": exit_price,
                     "exit_fee": exit_fee, "exit_reason": reason, "status": trade["Status"], "pnl": pnl,
                     "cash_before_order": buy.cash_before_order,
                     "cash_before_opening_entries": buy.cash_before_opening_entries})
    ledger = pd.DataFrame(rows)
    for index, row in ledger.iterrows():
        opening = pd.Timestamp(row.entry_date) + pd.Timedelta(hours=10)
        prior_closed = ledger.loc[ledger.status.eq("Closed") & ledger.exit_time.lt(opening)]
        held = ledger.loc[ledger.entry_time.lt(opening)
                          & (ledger.exit_time.gt(opening) | ledger.status.eq("Open"))]
        realized, held_cost = prior_closed.pnl.sum(), held.invested.sum()
        equal_number(initial_cash + realized - held_cost, row.cash_before_opening_entries,
                     "prior realized PnL/held capital/cash identity", atol=1e-6)
        budget = row.cash_before_opening_entries / 5
        require(np.floor(max(0, budget) / (row.entry_price + row.entry_fee / row.quantity)) == row.quantity,
                "Saved quantity differs from cash snapshot budget")
        ledger.loc[index, "realized_pnl_before_entry"] = realized
        ledger.loc[index, "held_cost_before_entry"] = held_cost
        ledger.loc[index, "entry_budget"] = budget
    require(not ledger.duplicated(TRADE_KEYS).any(), "Duplicate year/code/entry_date trade")
    require(len(orders.loc[orders.side.eq("writeoff")]) == len(report["writeoffs"]), "Writeoff count differs")
    return ledger, orders, report


def link_candidates(signals, ledger, orders, report):
    result = signals.copy()
    result["execution_result"] = "not_selected"
    result["evidence"] = "canonical_signal"
    result.loc[result.selected & ~result.entry_allowed, "execution_result"] = "entry_ineligible"
    result.loc[result.selected & result.entry_date.isna(), "execution_result"] = "no_next_day_in_year"
    buys = orders.loc[orders.side.eq("buy")] if not orders.empty else pd.DataFrame()
    seen = set()
    exclusions = {(pd.Timestamp(r["date"]), r["code"]): r["reason"] for r in report["exclusions"]}
    for index, row in result.loc[result.selected & result.entry_allowed].iterrows():
        day, code = row.entry_date, row.Code
        bought = buys.loc[buys.code.eq(code) & buys.date.dt.normalize().eq(day)] if len(buys) else buys
        if len(bought):
            require(len(bought) == 1, "Multiple buys for a candidate")
            reason, evidence = "filled", "saved_order"
            seen.add((day, code))
        elif (day, code) in exclusions:
            reason, evidence = exclusions[(day, code)], "saved_exclusion"
        elif len(ledger) and ((ledger.Code.eq(code)) & ledger.entry_time.lt(day + pd.Timedelta(hours=10))
                             & (ledger.exit_time.gt(day + pd.Timedelta(hours=10))
                                | ledger.status.eq("Open"))).any():
            reason, evidence = "already_held", "saved_trade_interval"
        else:
            reason, evidence = "unknown", "unconfirmed"
        result.loc[index, ["execution_result", "evidence"]] = [reason, evidence]
    orphan = []
    if len(buys):
        orphan = [{"entry_date": r.date.normalize(), "Code": r.code, "execution_result": "unknown",
                   "evidence": "saved_buy_without_candidate"} for r in buys.itertuples()
                  if (r.date.normalize(), r.code) not in seen]
    return result, orphan


def match_trades(a, b, horizon):
    for frame in (a, b):
        require(not frame.duplicated(TRADE_KEYS).any(), "Trade keys are not unique")
    matched = a.merge(b, on=TRADE_KEYS, how="outer", suffixes=("_A", "_B"), indicator=True,
                      validate="one_to_one")
    matched["group"] = matched.pop("_merge").map(
        {"both": "common", "left_only": "A_only", "right_only": "B_only"}
    ).astype(str)
    for column in ("quantity", "pnl", "invested"):
        for variant in ("A", "B"):
            matched[f"{column}_{variant}"] = matched[f"{column}_{variant}"].fillna(0)
    matched["contribution"] = matched.pnl_B - matched.pnl_A
    common = matched.group.eq("common")
    matched["same_path"] = common
    for column in ("entry_price", "exit_time", "exit_price", "exit_reason", "status"):
        matched["same_path"] &= matched[f"{column}_A"].eq(matched[f"{column}_B"])
    matched["same_quantity"] = common & matched.quantity_A.eq(matched.quantity_B)
    # A's per-share PnL is the accounting reference, not a causal counterfactual.
    unit_a = matched.pnl_A / matched.quantity_A.replace(0, np.nan)
    matched["quantity_contribution_A_reference"] = np.where(
        common, (matched.quantity_B - matched.quantity_A) * unit_a, 0
    )
    matched["path_contribution_A_reference"] = np.where(
        common, matched.contribution - matched.quantity_contribution_A_reference, 0
    )
    return matched.assign(horizon=horizon)


def daily_stock_pnl(ledger, prices, days):
    codes = sorted(ledger.Code.unique()) if len(ledger) else []
    daily = pd.DataFrame(0.0, index=days, columns=codes)
    close = prices.pivot(index="Date", columns="Code", values="Close").reindex(days)
    for row in ledger.itertuples():
        curve = pd.Series(0.0, index=days)
        active = days >= row.entry_date
        if row.status == "Closed":
            exit_day = row.exit_time.normalize()
            active &= days < exit_day
            curve.loc[days >= exit_day] = row.pnl
        marks = close.loc[active, row.Code]
        require(marks.notna().all(), f"Held mark missing: {row.Code}")
        curve.loc[active] = marks * row.quantity - row.invested
        daily[row.Code] += curve
    return daily


def block_intervals(daily, horizon, repetitions=2000):
    """Paired moving blocks of calendar dates, never crossing a year boundary."""
    rows = []
    rng = np.random.default_rng(42)
    for year, frame in daily.groupby(daily.index.year):
        n = len(frame)
        require(n > 0, "Bootstrap requires calendar dates")
        for block in (20, 60):
            length = min(block, n)
            starts = rng.integers(0, n - length + 1, size=(repetitions, int(np.ceil(n / length))))
            indices = (starts[:, :, None] + np.arange(length)).reshape(repetitions, -1)[:, :n]
            for metric in ["roc_auc", "brier_score", "ic_mean"]:
                values = frame[f"{metric}_delta"].to_numpy(float)
                sampled = values[indices]
                count = np.isfinite(sampled).sum(axis=1)
                samples = np.nansum(sampled, axis=1) / np.where(count, count, np.nan)
                finite = samples[np.isfinite(samples)]
                lo, hi = np.quantile(finite, [.025, .975]) if len(finite) else (np.nan, np.nan)
                rows.append({"horizon": horizon, "year": year, "metric": metric,
                             "estimand": "mean_daily_B_minus_A", "block_days": block,
                             "effective_block_days": length, "calendar_days": n,
                             "valid_metric_days": int(np.isfinite(values).sum()), "repetitions": repetitions,
                             "valid_repetitions": len(finite), "seed": 42,
                             "mean_delta": np.nanmean(values) if np.isfinite(values).any() else np.nan,
                             "ci95_low": lo, "ci95_high": hi})
    return pd.DataFrame(rows)


def daily_metrics(pair):
    observed = pair.loc[pair.label_observed]
    rows = []
    ic = {v: daily_rank_ic(observed, prob_col=f"score_{v}") for v in ("A", "B")}
    for day, frame in observed.groupby("Date"):
        row = {"Date": day, "sample_count": len(frame)}
        for variant in ("A", "B"):
            metrics = calculate_classification_metrics(frame.Y_Label, frame[f"score_{variant}"])
            row.update({f"{m}_{variant}": metrics[m] for m in ("roc_auc", "brier_score")})
            row[f"ic_mean_{variant}"] = ic[variant].get(day, np.nan)
        for metric in ("roc_auc", "brier_score", "ic_mean"):
            row[f"{metric}_delta"] = row[f"{metric}_B"] - row[f"{metric}_A"]
        rows.append(row)
    return pd.DataFrame(rows).set_index("Date").reindex(sorted(pair.Date.unique()))


def feature_diagnostics(runs, pairs, out):
    """Verify paired stores, sample correlations, and reconstructed availability joins."""
    from experiments.features.panel_builder import (
        LoadedFeatureSource,
        _map_to_next_panel_day,
        _parse_source_spec,
        _validate_source_frame,
        assemble_feature_panel,
    )

    a, b = (runs[(5, v)]["config"] for v in ("A", "B"))
    require(all(runs[(h, v)]["config"]["features"]["materialized_dir"]
                == runs[(5, v)]["config"]["features"]["materialized_dir"]
                for h in (5, 20) for v in ("A", "B")), "Expected shared stores across horizons")
    paired = verify_paired_features(a, b)
    roots = {v: Path(runs[(5, v)]["config"]["features"]["materialized_dir"]) for v in ("A", "B")}
    manifests = {v: read_json(roots[v] / "feature_manifest.json") for v in ("A", "B")}
    for variant in ("A", "B"):
        for name, digest in manifests[variant]["file_hashes"].items():
            require(sha256(roots[variant] / name) == digest, f"Feature hash mismatch: {variant}/{name}")
    samples = []
    for horizon, pair in pairs.items():
        for year, frame in pair.groupby(pair.Date.dt.year):
            samples.append(frame[KEYS].sample(n=min(10_000, len(frame)), random_state=42)
                           .assign(horizon=horizon, year=year))
    keys = pd.concat(samples, ignore_index=True)
    atomic_parquet(out / "correlation_sample_keys.parquet", keys)
    selected = keys.groupby("Code")
    columns = b["feature_columns"]
    sample_frames, timing = [], []
    dataset_root = Path(b["dataset"]["root"])
    processed_manifest = read_json(dataset_root / "processed_manifest.json")
    print("Checking feature hashes, common inputs and availability joins", flush=True)
    for index, name in enumerate(manifests["B"]["file_hashes"], 1):
        code = Path(name).stem
        panel = pd.read_parquet(roots["B"] / name)
        context_columns = ["Date", "Code", "Volume", "UniverseEligible"]
        context_columns = [c for c in context_columns if c in panel]
        context = pd.read_parquet(roots["A"] / name, columns=context_columns)
        require(context.equals(panel[context_columns]), f"A/B volume/universe conditions differ: {code}")
        require(sha256(dataset_root / "processed" / name) == processed_manifest["files"][name],
                f"Processed input hash mismatch: {name}")
        base = pd.read_parquet(dataset_root / "processed" / name, columns=["Date", "Code", "Close", "Volume"])
        base["Code"] = base.Code.astype("string")
        try:
            source_frame, _ = build_psychology_features(
                base, PsychologyFeatureConfig(**b["features"].get("psychology", {}))
            )
        except PsychologyInputError as exc:
            # A short/newly listed stock may have no warmed psychology input.
            require("워밍업 구간을 넘긴 행이 없습니다" in str(exc), str(exc))
            source_frame = base[KEYS].iloc[:0].assign(AvailableDate=pd.NaT)
            for feature in TREATMENT_FEATURES:
                source_frame[feature] = pd.Series(dtype=float)
        spec = _parse_source_spec({"name": "psychology", "path": str(out / "reconstructed.parquet"),
                                  "columns": list(TREATMENT_FEATURES), "apply_period": "one_day",
                                  "missing": {"policy": "forward_fill", "max_staleness_trading_days": 0}})
        source = LoadedFeatureSource(spec, _validate_source_frame(spec, source_frame), {})
        regenerated, _ = assemble_feature_panel(base, [source])
        require(np.allclose(regenerated[list(TREATMENT_FEATURES)], panel[list(TREATMENT_FEATURES)],
                            rtol=0, atol=1e-12, equal_nan=True), f"Psychology join mismatch: {code}")
        mapped = _map_to_next_panel_day(base, source)
        mapped = mapped.rename(columns={"Date": "observation_date", "_effective_date": "join_date"})
        mapped = mapped.loc[mapped.join_date.dt.year.between(2019, 2025),
                            ["Code", "observation_date", "AvailableDate", "join_date"]]
        timing.append(mapped)
        if code in selected.groups:
            sample_frames.append(keys.loc[selected.groups[code]].merge(panel[KEYS + columns], on=KEYS,
                                                                       validate="many_to_one"))
        if index % 100 == 0:
            print(f"Feature/timing verification: {index}/{len(manifests['B']['file_hashes'])}", flush=True)
    sample = pd.concat(sample_frames, ignore_index=True)
    require(len(sample) == len(keys), "Correlation sample rows missing")
    rows = []
    for (horizon, year), frame in sample.groupby(["horizon", "year"]):
        ranked = frame[columns].rank()
        for psych in TREATMENT_FEATURES:
            correlations = ranked[a["feature_columns"]].corrwith(ranked[psych])
            for feature, value in correlations.items():
                rows.append({"horizon": horizon, "year": year, "psychology_feature": psych,
                             "existing_feature": feature, "spearman": value, "sample_rows": len(frame),
                             "paired_nonmissing_rows": int(frame[[psych, feature]].notna().all(axis=1).sum()),
                             "seed": 42})
    pd.DataFrame(rows).to_csv(out / "feature_correlations.csv", index=False)
    timing = pd.concat(timing, ignore_index=True)
    require(timing.AvailableDate.le(timing.join_date).all()
            and timing.observation_date.lt(timing.join_date).all(), "Psychology availability timing failed")
    atomic_parquet(out / "feature_timing.parquet", timing)
    # LightGBM text dumps retain both gain importance and actual split counts.
    import lightgbm as lgb

    importance = []
    for horizon in (5, 20):
        model_paths = runs[(horizon, "B")]["models"]
        require(len(model_paths) == 7, "Expected seven B models per horizon")
        for model_path in model_paths:
            model = lgb.Booster(model_file=str(model_path))
            fold = int(model_path.stem.split("_fold")[1].split("_")[0])
            gains, splits = model.feature_importance("gain"), model.feature_importance("split")
            require(model.feature_name() == columns, f"B model feature contract differs: {model_path}")
            for feature, gain, split in zip(model.feature_name(), gains, splits):
                importance.append({"horizon": horizon, "year": 2019 + fold, "feature": feature,
                                   "psychology": feature in TREATMENT_FEATURES, "gain": gain,
                                   "gain_share": gain / gains.sum() if gains.sum() else 0,
                                   "split_count": split, "split_share": split / splits.sum() if splits.sum() else 0})
    importance = pd.DataFrame(importance)
    importance.to_csv(out / "feature_importance_by_model.csv", index=False)
    importance.groupby(["horizon", "feature", "psychology"]).agg(
        gain=("gain", "sum"), split_count=("split_count", "sum"),
        mean_gain_share=("gain_share", "mean"), mean_split_share=("split_share", "mean")
    ).reset_index().to_csv(out / "feature_importance_summary.csv", index=False)
    return {"paired_features": paired, "feature_hashes_verified": True,
            "psychology_join_rows": len(timing), "available_equals_join_rows": int(timing.AvailableDate.eq(timing.join_date).sum()),
            "psychology_values_reconstructed": True,
            "base_timing": "T-day prices; psychology values observed before join date",
            "flow_timing": "flow AvailableDate dropped; flow features joined on original Date (local_panel.py)"}


def analyze_execution(runs, pairs, out):
    summaries, matches, connections, stock_rows, gap_rows, audits, orphans = [], [], [], [], [], [], []
    cash_events = []
    config = runs[(5, "A")]["config"]
    prices = load_parquet_data(config["features"]["materialized_dir"], "2019-01-07", "2025-12-31",
                               columns_only=["Date", "Code", "Open", "High", "Low", "Close", "Sigma", "Trading_Halt"],
                               strict=True)
    prices["Code"] = prices.Code.astype(str)
    for horizon in (5, 20):
        pair = pairs[horizon]
        for year in range(2019, 2026):
            market = prices.loc[prices.Date.dt.year.eq(year)]
            year_pair = pair.loc[pair.Date.dt.year.eq(year)].copy()
            ledgers, stock_paths, equities, metrics = {}, {}, {}, {}
            for variant in ("A", "B"):
                run = runs[(horizon, variant)]
                initial = run["config"]["backtest"]["initial_cash"]
                ledger, orders, report = annual_ledger(run["root"], year, initial)
                if len(orders):
                    cash_events.append(orders.assign(horizon=horizon, year=year, variant=variant))
                predictions = run["history"].loc[run["history"].Date.dt.year.eq(year)]
                signals = candidate_signals(run["config"], predictions, market)
                linked, missing = link_candidates(signals, ledger, orders, report)
                orphans.extend(dict(horizon=horizon, year=year, variant=variant, **row) for row in missing)
                # Each signal records scores from both runs, even when one side is below threshold.
                linked = linked.merge(year_pair[KEYS + ["score_A", "score_B", "score_delta", "fold_id", "label_observed", "Y_Label"]],
                                      on=KEYS, validate="one_to_one")
                linked.insert(0, "horizon", horizon)
                linked.insert(1, "year", year)
                linked.insert(2, "variant", variant)
                connections.append(linked)
                if len(ledger):
                    info = linked.loc[linked.execution_result.eq("filled"), ["Code", "entry_date", "Date", "prob_up", "rank", "fold_id"]]
                    ledger = ledger.merge(info, on=["Code", "entry_date"], how="left", validate="one_to_one")
                ledgers[variant] = ledger
                folder = run["root"] / "years" / str(year)
                equity = pd.read_csv(folder / "equity_curve.csv", index_col=0, parse_dates=True).Equity
                equities[variant] = equity
                stock_paths[variant] = daily_stock_pnl(ledger, market, equity.index)
                reconstructed = initial + stock_paths[variant].sum(axis=1)
                residual = (reconstructed - equity).abs().max()
                require(residual <= 1, f"Daily equity residual > 1 won: H{horizon}/{year}/{variant}/{residual}")
                returns = equity.pct_change(fill_method=None)
                returns.iloc[0] = equity.iloc[0] / initial - 1
                saved_returns = pd.read_csv(folder / "daily_returns.csv", index_col=0, parse_dates=True).Portfolio
                require(np.allclose(returns, saved_returns, rtol=0, atol=1e-10), "Daily returns differ")
                saved = read_json(folder / "backtest_metrics.json")
                closed = read_codes(folder / "trades.csv")
                closed = closed.loc[closed.Status.eq("Closed")] if len(closed) else closed
                metrics[variant] = calculate_trading_metrics(returns, closed)
                for name in ("total_return", "max_drawdown", "sharpe_ratio", "number_of_trades"):
                    equal_number(metrics[variant][name], saved[name], f"backtest/{horizon}/{year}/{variant}/{name}")
                equal_number(equity.iloc[-1], saved["final_equity"], "final equity", atol=1)
                drawdown = equity / equity.cummax().clip(lower=initial) - 1
                trough = drawdown.idxmin()
                before = equity.loc[:trough]
                peak = before.idxmax() if before.max() >= initial else equity.index[0]
                audits.append({"horizon": horizon, "year": year, "variant": variant,
                               "daily_equity_max_residual": residual, "selected_candidates": int(linked.selected.sum()),
                               "filled_candidates": int(linked.execution_result.eq("filled").sum()),
                               "buy_orders": int(orders.side.eq("buy").sum()) if len(orders) else 0,
                               "unknown_candidates": int(linked.execution_result.eq("unknown").sum()),
                               "unlinked_buys": len(missing), "drawdown_peak": peak, "drawdown_trough": trough,
                               "max_drawdown": metrics[variant]["max_drawdown"],
                               "sharpe_ratio": metrics[variant]["sharpe_ratio"]})
            require(equities["A"].index.equals(equities["B"].index), "A/B equity calendar differs")
            # Supply empty ledgers with the same columns for zero-trade years.
            if ledgers["A"].empty or ledgers["B"].empty:
                template = ledgers["A"] if len(ledgers["A"]) else ledgers["B"]
                if template.empty:
                    template = pd.DataFrame(columns=TRADE_KEYS + ["quantity", "pnl", "invested", "entry_price", "exit_time", "exit_price", "exit_reason", "status"])
                ledgers = {v: frame if len(frame) else template.iloc[:0].copy() for v, frame in ledgers.items()}
            matched = match_trades(ledgers["A"], ledgers["B"], horizon)
            matches.append(matched)
            delta = equities["B"].iloc[-1] - equities["A"].iloc[-1]
            contributions = matched.groupby("group").contribution.sum()
            residual = delta - matched.contribution.sum()
            require(abs(residual) <= 1, f"Year decomposition residual > 1 won: {horizon}/{year}/{residual}")
            summaries.append({"horizon": horizon, "year": year, "final_equity_A": equities["A"].iloc[-1],
                              "final_equity_B": equities["B"].iloc[-1], "equity_delta": delta,
                              **{f"{group}_contribution": contributions.get(group, 0) for group in ("common", "A_only", "B_only")},
                              "quantity_contribution_A_reference": matched.quantity_contribution_A_reference.sum(),
                              "path_contribution_A_reference": matched.path_contribution_A_reference.sum(),
                              "residual": residual,
                              **{f"{m}_{v}": metrics[v][m] for v in ("A", "B") for m in ("total_return", "max_drawdown", "sharpe_ratio")}})
            stocks = stock_paths["B"].subtract(stock_paths["A"], fill_value=0)
            require(np.allclose(stocks.sum(axis=1), equities["B"] - equities["A"], rtol=0, atol=1), "Stock paths do not reconcile")
            long = stocks.rename_axis(index="Date", columns="Code").stack().rename("pnl_delta").reset_index()
            for variant in ("A", "B"):
                levels = stock_paths[variant].reindex(columns=stocks.columns, fill_value=0)
                long[f"pnl_{variant}"] = levels.to_numpy().ravel()
            long["horizon"], long["year"] = horizon, year
            stock_rows.append(long)
            gap = pd.DataFrame({"Date": equities["A"].index, "horizon": horizon, "year": year,
                                "equity_A": equities["A"].values, "equity_B": equities["B"].values})
            gap["equity_delta"] = gap.equity_B - gap.equity_A
            gap["daily_gap_change"] = gap.equity_delta.diff().fillna(gap.equity_delta)
            gap_rows.append(gap)
            print(f"Reconciled H{horizon}/{year}: B-A {delta:,.0f} won, residual {residual:.8f}", flush=True)
    summary = pd.DataFrame(summaries)
    matched = pd.concat(matches, ignore_index=True)
    signals = pd.concat(connections, ignore_index=True)
    gaps = pd.concat(gap_rows, ignore_index=True)
    summary.to_csv(out / "pnl_by_year.csv", index=False)
    atomic_parquet(out / "signal_execution_links.parquet", signals)
    signals.loc[signals.selected].to_csv(out / "candidate_execution_links.csv", index=False)
    pd.DataFrame(orphans, columns=["horizon", "year", "variant", "entry_date", "Code", "execution_result", "evidence"]).to_csv(out / "unlinked_entries.csv", index=False)
    matched.to_csv(out / "trade_matches.csv", index=False)
    matched.groupby(["horizon", "year", "Code", "group"]).agg(
        pnl_A=("pnl_A", "sum"), pnl_B=("pnl_B", "sum"), contribution=("contribution", "sum"),
        entries=("entry_date", "size")
    ).reset_index().to_csv(out / "pnl_by_stock.csv", index=False)
    atomic_parquet(out / "daily_stock_pnl.parquet", pd.concat(stock_rows, ignore_index=True))
    gaps.to_csv(out / "daily_equity_gap.csv", index=False)
    pd.DataFrame(audits).to_csv(out / "execution_validation.csv", index=False)
    pd.concat(cash_events, ignore_index=True).to_csv(out / "cash_order_history.csv", index=False)
    signals.groupby(["horizon", "year", "variant", "execution_result", "evidence"]).size().rename("rows").reset_index().to_csv(out / "execution_counts.csv", index=False)
    selected = signals.pivot(index=["horizon", "year", "Date", "Code"], columns="variant", values="selected").reset_index()
    selected["replacement"] = np.select([selected.A & selected.B, selected.A, selected.B], ["common", "A_only", "B_only"], default="neither")
    selected.groupby(["horizon", "year", "replacement"]).size().rename("rows").reset_index().to_csv(out / "candidate_replacements.csv", index=False)
    return summary, matched, signals, gaps


def make_plots(summary, gaps, out):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    figures = out / "figures"
    figures.mkdir(exist_ok=True)
    fig, axes = plt.subplots(7, 2, figsize=(14, 19))
    for column, horizon in enumerate((5, 20)):
        for index, year in enumerate(range(2019, 2026)):
            frame = gaps.loc[gaps.horizon.eq(horizon) & gaps.year.eq(year)]
            ax = axes[index, column]
            ax.plot(pd.to_datetime(frame.Date), frame.equity_delta / 1e6, color="#235b8a")
            ax.axhline(0, color="grey", lw=.5)
            ax.set_title(f"H{horizon} {year}: B - A equity (million KRW)")
            ax.tick_params(axis="x", labelrotation=25)
    fig.tight_layout()
    fig.savefig(figures / "equity_gap.png", dpi=150)
    plt.close(fig)
    fig, axes = plt.subplots(2, 1, figsize=(12, 8))
    for ax, horizon in zip(axes, (5, 20)):
        frame = summary.loc[summary.horizon.eq(horizon)]
        x = np.arange(len(frame))
        for offset, (group, color) in enumerate(zip(("common", "B_only", "A_only"), ("#235b8a", "#25805b", "#b85748"))):
            ax.bar(x + (offset - 1) * .23, frame[f"{group}_contribution"] / 1e6,
                   width=.23, label=group, color=color)
        ax.plot(x, frame.equity_delta / 1e6, "ko", label="total B-A")
        ax.set_xticks(x, frame.year)
        ax.axhline(0, color="grey", lw=.5)
        ax.set_title(f"H{horizon}: annual PnL contributions (million KRW)")
        ax.legend()
    fig.tight_layout()
    fig.savefig(figures / "pnl_contributions.png", dpi=150)
    plt.close(fig)


def write_report(out, summary, matched, signals, gaps, prediction, uncertainty, validation):
    signal_lookup = signals.set_index(["horizon", "year", "variant", "Date", "Code"])
    mean_gaps = {h: (summary.loc[summary.horizon.eq(h), "total_return_B"]
                    - summary.loc[summary.horizon.eq(h), "total_return_A"]).mean() * 100
                 for h in (5, 20)}
    lines = ["# 저장된 심리 피처 A/B 성과 격차 분석", "",
             f"**확인된 사실:** B−A의 독립 연도 수익률 평균 차이는 H5 {mean_gaps[5]:+.4f}%p, H20 {mean_gaps[20]:+.4f}%p다.", "",
             "**확인된 사실:** 아래 금액은 저장된 2019~2025년 H5·H20 거래 경로의 B−A 차이다. 매년 초기자금 10,000,000원으로 독립 평가했다.", "",
             "**현재 자료로 미확인:** 개별 심리 피처의 인과적 효과와 다른 기간에서의 효과 지속 여부. 재학습·임계값·정보 시점 변경은 수행하지 않았다.", "",
             "## 재현과 해석 범위", "",
             f"**확인된 사실:** 입력 해시, 설정, 예측·라벨·관측 여부·fold를 검증했다. ROC-AUC·PR-AUC·Brier·Rank IC의 연도별 및 전체 재현 허용 오차는 1e-10, 14개 연도·기간 조합의 최대 손익 분해 잔차는 {summary.residual.abs().max():.8f}원이다.", "",
             "**확인된 사실:** ML 평가는 관측 가능한 라벨만 사용한다. 거래 경로에는 미관측 라벨 행도 포함한다. 상승 라벨은 공용 평가함수의 Y_Label=2이며, PR-AUC는 공용 함수의 사다리꼴 적분이다.", "",
             "**확인된 사실:** 0.65 이상, 신호일 거래정지·상장 조건을 통과한 종목 중 일별 상위 5개다. 동점은 pivot의 종목코드 순서로 처리한다. 진입일과 지연 구간의 예측 존재 조건을 적용하므로 fold·연말 경계를 건너 신호를 넘기지 않는다. 상위 5개는 일별 후보 제한이며 동시 보유 한도가 아니다.", "",
             "**확인된 사실:** 공통 거래는 연도·종목·진입일로 대응한다. 공통 기여=PnL_B−PnL_A, B만 기여=PnL_B, A만 기여=−PnL_A다. 수수료와 연말 평가손익을 포함하고 상장폐지 writeoff는 거래 손익에 한 번만 반영했다.", "",
             "**확인된 사실:** 공통 거래의 수량 기여는 (수량_B−수량_A)×A의 주당 손익, 경로 기여는 나머지다. 이는 A 경로 기준의 정산 항등식이다. 청산까지 같은 경로에서는 수량 기여로 전부 정산된다.", "",
             "**자료가 지지하는 가설:** 수량 차이는 신호 점수 자체보다 이전 거래의 실현손익과 기존 보유에 묶인 현금의 영향을 받는다. 저장 주문으로 재구성한 진입 전 현금과 예산을 함께 제시하며, 수량 차이를 독립적인 원인으로 단정하지 않는다.", "",
             "## 전체 지표와 독립 연도 평균", ""]
    for horizon in (5, 20):
        year_summary = summary.loc[summary.horizon.eq(horizon)]
        pooled = prediction.loc[prediction.horizon.eq(horizon) & prediction.year.eq(0)].set_index("variant")
        delta = pooled.loc["B", METRICS] - pooled.loc["A", METRICS]
        lines.extend([f"**확인된 사실, H{horizon}:** 전체 ROC-AUC 차이 {delta.roc_auc:+.6f}, PR-AUC {delta.pr_auc:+.6f}, Brier {delta.brier_score:+.6f}, 일별 평균 Rank IC {delta.ic_mean:+.6f}. Brier는 낮을수록 좋다.", "",
                      f"**확인된 사실, H{horizon}:** 독립 연도 수익률 산술평균 A={year_summary.total_return_A.mean():.2%}, B={year_summary.total_return_B.mean():.2%}, 차이={(year_summary.total_return_B-year_summary.total_return_A).mean():+.2%}p. 7년 연속 투자 수익률로 해석하지 않는다.", ""])
        signed = year_summary[["common_contribution", "A_only_contribution", "B_only_contribution"]].sum()
        lines.extend([f"**확인된 사실, H{horizon}:** 독립 연도별 격차의 금액 합은 공통 진입 {signed.common_contribution:+,.0f}원, A만 진입의 반대 기여 {signed.A_only_contribution:+,.0f}원, B만 진입 {signed.B_only_contribution:+,.0f}원으로 정산된다. 각각의 합도 연속 투자 결과가 아니다.", ""])
    common_all = matched.loc[matched.group.eq("common")]
    lines.extend([f"**확인된 사실:** 두 기간 합계 공통 진입 {len(common_all)}건 중 동일 경로는 {int(common_all.same_path.sum())}건이다. 동일 경로의 손익 격차는 수량 차이로 전부 정산된다. 동일 경로는 진입 가격·청산 시각·청산 가격·사유·상태가 같은 경우다.", ""])
    lines.extend(["![자산 격차 추이](figures/equity_gap.png)", "", "![손익 기여도](figures/pnl_contributions.png)", "",
                  "## 불확실성", "",
                  "**확인된 사실:** A/B를 같은 날짜 블록으로 묶어 연도 안에서 20·60거래일 이동 블록을 각 2,000회 재표집했다. 시드 42, 백분위 95% 구간이다. 단일 클래스의 일별 AUC와 상수 라벨·점수의 Rank IC는 계산 불가로 유지하고 유효 날짜·반복 수를 기록했다.", "",
                  "**현재 자료로 미확인:** 이 구간은 일별 평균 AUC·Brier·Rank IC 차이에 대한 구간이다. 전체 또는 연도별 pooled AUC 차이의 신뢰구간이 아니며, 거래 수익률의 신뢰구간도 아니다.", ""])
    for horizon in (5, 20):
        for metric in ("roc_auc", "brier_score", "ic_mean"):
            frame = uncertainty.loc[uncertainty.horizon.eq(horizon) & uncertainty.metric.eq(metric)]
            excludes = frame.loc[(frame.ci95_low > 0) | (frame.ci95_high < 0)]
            detail = ", ".join(f"{int(r.year)}/{int(r.block_days)}일" for r in excludes.itertuples()) or "없음"
            lines.extend([f"**확인된 사실:** H{horizon} {metric}, 95% 구간이 0을 제외하는 연도/블록: {detail}. 수치는 [uncertainty.csv](uncertainty.csv)에 있다.", ""])
    lines.extend(["## 피처와 정보 시점", "",
                  f"**확인된 사실:** 14개 B 모델의 gain 중요도와 분할 사용량을 집계했다. 공통 테스트 입력에서 연도·기간별 최대 10,000행을 시드 42로 추출했다. {validation['features']['psychology_join_rows']:,}개 심리 입력의 관측일·AvailableDate·실제 결합일을 재구성했고, 저장값과의 일치를 1e-12로 검증했다.", "",
                  "**확인된 사실:** 기존 가격·수급 피처는 T일 입력에 결합된다. 심리 피처는 관측일 다음 해당 종목 거래일의 AvailableDate를 통해 T일에 결합된다. 따라서 심리 입력은 기존 가격 입력보다 한 관측일 앞선 정보를 사용한다. 실제 결합 기록은 [feature_timing.parquet](feature_timing.parquet)에 있다.", "",
                  "**자료가 지지하는 가설:** 중요도·분할 사용량은 모델이 심리 입력을 사용했는지, Spearman 상관은 기존 입력과 정보가 겹치는지를 보여준다.", "",
                  "**현재 자료로 미확인:** 높은 중요도는 추가 예측 효과의 증거가 아니며, 높은 상관은 성과 격차의 원인을 확정하지 않는다. 정보 시점 차이의 독립 효과도 현재 A/B 자료만으로 분리할 수 없다.", ""])
    importance = pd.read_csv(out / "feature_importance_by_model.csv")
    for horizon in (5, 20):
        frame = importance.loc[importance.horizon.eq(horizon) & importance.psychology]
        per_year = frame.groupby("year").gain_share.sum()
        lines.extend([f"**확인된 사실:** H{horizon} 심리 4개 입력의 연도별 gain 비중 합은 {per_year.min():.2%}~{per_year.max():.2%}, 7개 모델 분할 사용 합은 {int(frame.split_count.sum()):,}회다.", ""])
    correlations = pd.read_csv(out / "feature_correlations.csv").dropna(subset=["spearman"])
    for psych, frame in correlations.groupby("psychology_feature"):
        row = frame.loc[frame.spearman.abs().idxmax()]
        lines.extend([f"**확인된 사실:** {psych}의 최대 절대 상관은 H{int(row.horizon)}/{int(row.year)}의 {row.existing_feature}, Spearman={row.spearman:+.4f}다.", ""])
    lines.extend(["## 연도별 거래 경로와 상위 5개 사례", "",
                  "사례는 해당 연도의 |B−A 손익 기여| 상위 5개 거래다. 점수·순위는 신호일 기준, 금액은 진입 수수료 포함이다. 단독 진입의 상대 모델 점수도 동일 신호일에서 확인한다.", ""])
    order = [(20, 2020), (20, 2022), (5, 2020), (5, 2021)]
    order += [(h, y) for h in (5, 20) for y in range(2019, 2026) if (h, y) not in order]
    top_frames = []
    audit = pd.read_csv(out / "execution_validation.csv")
    for horizon, year in order:
        row = summary.loc[summary.horizon.eq(horizon) & summary.year.eq(year)].iloc[0]
        trades = matched.loc[matched.horizon.eq(horizon) & matched.year.eq(year)]
        top = trades.loc[trades.contribution.abs().sort_values(ascending=False).head(5).index]
        top_frames.append(top)
        candidates = signals.loc[signals.horizon.eq(horizon) & signals.year.eq(year) & signals.selected]
        gap = gaps.loc[gaps.horizon.eq(horizon) & gaps.year.eq(year)]
        max_change = gap.loc[gap.daily_gap_change.abs().idxmax()]
        common = trades.loc[trades.group.eq("common")]
        lines.extend([f"### H{horizon} / {year}", "",
                      f"**확인된 사실:** 최종자산 차이 {row.equity_delta:+,.0f}원 = 공통 {row.common_contribution:+,.0f} + B만 {row.B_only_contribution:+,.0f} + A만의 반대 기여 {row.A_only_contribution:+,.0f}. 잔차 {row.residual:.8f}원.", "",
                      f"**확인된 사실:** 공통 진입 {len(common)}건, A만 {int(trades.group.eq('A_only').sum())}건, B만 {int(trades.group.eq('B_only').sum())}건. 공통 중 동일 경로 {int(common.same_path.sum())}건, 동일 수량 {int(common.same_quantity.sum())}건.", "",
                      f"**확인된 사실:** 자산 격차가 하루에 가장 크게 변한 날짜는 {pd.Timestamp(max_change.Date).date()}, 변화 {max_change.daily_gap_change:+,.0f}원, 이날 격차 {max_change.equity_delta:+,.0f}원이다.", ""])
        if len(top) < 5:
            lines.extend([f"**확인된 사실:** 대응 거래가 {len(trades)}건이므로 사례는 {len(top)}건이다. 거래가 없는 조합에 사례를 만들지 않았다.", ""])
        for variant in ("A", "B"):
            info = audit.loc[audit.horizon.eq(horizon) & audit.year.eq(year) & audit.variant.eq(variant)].iloc[0]
            counts = candidates.loc[candidates.variant.eq(variant)].execution_result.value_counts()
            detail = ", ".join(f"{name} {count}건" for name, count in counts.items()) or "후보 없음"
            lines.extend([f"**확인된 사실, {variant}:** 후보 처리 {detail}. 최대낙폭 {info.max_drawdown:.2%}, 구간 {pd.Timestamp(info.drawdown_peak).date()}~{pd.Timestamp(info.drawdown_trough).date()}, Sharpe {info.sharpe_ratio:.4f}. 전체 자산 경로에서 계산했다.", ""])
        for index, trade in enumerate(top.to_dict("records"), 1):
            lines.extend([f"**확인된 사실, 사례 {index}:** {trade['Code']} / 진입 {pd.Timestamp(trade['entry_date']).date()} / {trade['group']} / 기여 {trade['contribution']:+,.0f}원.", ""])
            for variant in ("A", "B"):
                if trade[f"quantity_{variant}"] == 0:
                    other = "B" if variant == "A" else "A"
                    day = trade.get(f"Date_{other}")
                    lookup_key = (horizon, year, variant, day, trade["Code"])
                    if lookup_key in signal_lookup.index:
                        candidate = signal_lookup.loc[lookup_key]
                        lines.extend([f"{variant}: 동일 신호일 점수 {candidate.prob_up:.6f}, 0.65 통과={bool(candidate.threshold_pass)}, 상위 5개={bool(candidate.selected)}, 처리={candidate.execution_result}. 실제 진입 없음.", ""])
                    else:
                        lines.extend([f"**현재 자료로 미확인, {variant}:** 대응 신호 행 없음. 실제 진입 없음.", ""])
                    continue
                lines.extend([f"{variant}: 신호 {pd.Timestamp(trade[f'Date_{variant}']).date()}, 점수 {trade[f'prob_up_{variant}']:.6f}, 순위 {trade[f'rank_{variant}']:.0f}, {trade[f'quantity_{variant}']:.0f}주, 체결금액 {trade[f'invested_{variant}']:,.0f}원. 진입 전 현금 {trade[f'cash_before_opening_entries_{variant}']:,.0f}원. 청산/평가 {pd.Timestamp(trade[f'exit_time_{variant}']).date()} ({trade[f'exit_reason_{variant}']}), 손익 {trade[f'pnl_{variant}']:+,.0f}원.", ""])
                if trade["group"] == "common":
                    lines.extend([f"{variant} 현금 경로: 초기 10,000,000원 + 이전 실현손익 {trade[f'realized_pnl_before_entry_{variant}']:+,.0f}원 − 기존 보유 투입금 {trade[f'held_cost_before_entry_{variant}']:,.0f}원 = 진입 전 현금. 그 현금의 1/5인 {trade[f'entry_budget_{variant}']:,.0f}원이 이 주문의 예산이다.", ""])
            if trade["group"] == "common":
                lines.extend([f"**확인된 사실:** 동일 경로={trade['same_path']}, 동일 수량={trade['same_quantity']}. A 경로 기준 수량 기여 {trade['quantity_contribution_A_reference']:+,.0f}원, 경로 기여 {trade['path_contribution_A_reference']:+,.0f}원. 앞선 현금 변동은 거래 대응표와 주문 현금 이력에서 추적할 수 있다.", ""])
    pd.concat(top_frames, ignore_index=True).to_csv(out / "top_cases.csv", index=False)
    lines.extend(["## 산출물", "",
                  "[예측 지표](prediction_metrics.csv), [연도별 손익](pnl_by_year.csv), [종목별 손익](pnl_by_stock.csv), [거래 대응](trade_matches.csv), [대표 사례](top_cases.csv).", "",
                  "[전체 신호·체결 연결](signal_execution_links.parquet), [선택 후보 연결 CSV](candidate_execution_links.csv), [후보 교체](candidate_replacements.csv), [미연결 진입](unlinked_entries.csv), [주문 현금 이력](cash_order_history.csv), [체결 검증](execution_validation.csv).", "",
                  "[일별 종목 손익](daily_stock_pnl.parquet), [자산 격차](daily_equity_gap.csv), [점수 구간](score_bins.csv), [점수 구간 이동](score_bin_transitions.csv), [불확실성](uncertainty.csv), [일별 ML 지표](daily_prediction_metrics.csv).", "",
                  "[모델별 중요도](feature_importance_by_model.csv), [중요도 집계](feature_importance_summary.csv), [상관](feature_correlations.csv), [표본 키](correlation_sample_keys.parquet), [정보 시점](feature_timing.parquet), [입력 해시](input_hashes.csv), [완료 검증](validation.json).", "",
                  "**현재 자료로 미확인:** `unknown`은 저장된 주문·제외 기록·보유 구간으로 확인되지 않은 사유다. 이 경우 원인 추정으로 대체하지 않는다.", ""])
    (out / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def analyze(suite, validate_only=False):
    suite = chart_path(suite)
    out = suite / "analysis"
    out.mkdir(exist_ok=True)
    validation = {"status": "running", "source_run_id": read_json(suite / "status.json")["run_id"],
                  "metric_tolerance": 1e-10, "pnl_tolerance_won": 1, "training_performed": False}
    atomic_json(out / "validation.json", validation)
    try:
        runs, pairs = load_suite(suite, out)
        prediction = reproduce_metrics(runs, out)
        validation.update(status="input_and_metrics_passed", paired_prediction_rows={str(h): len(p) for h, p in pairs.items()})
        atomic_json(out / "validation.json", validation)
        if validate_only:
            return out
        summary, matched, signals, gaps = analyze_execution(runs, pairs, out)
        bins, transitions, intervals, daily = [], [], [], []
        for horizon, pair in pairs.items():
            binned, moved = score_diagnostics(pair, horizon)
            bins.append(binned)
            transitions.append(moved)
            metrics = daily_metrics(pair)
            intervals.append(block_intervals(metrics, horizon))
            daily.append(metrics.rename_axis("Date").reset_index().assign(horizon=horizon))
            print(f"Completed fixed bins and 20/60-day bootstrap: H{horizon}", flush=True)
        pd.concat(bins).to_csv(out / "score_bins.csv", index=False)
        pd.concat(transitions).to_csv(out / "score_bin_transitions.csv", index=False)
        uncertainty = pd.concat(intervals, ignore_index=True)
        uncertainty.to_csv(out / "uncertainty.csv", index=False)
        pd.concat(daily, ignore_index=True).to_csv(out / "daily_prediction_metrics.csv", index=False)
        validation["features"] = feature_diagnostics(runs, pairs, out)
        validation.update(status="complete", annual_combinations=len(summary),
                          max_pnl_residual_won=float(summary.residual.abs().max()),
                          unknown_candidates=int(signals.execution_result.eq("unknown").sum()),
                          unlinked_entries=len(pd.read_csv(out / "unlinked_entries.csv")))
        make_plots(summary, gaps, out)
        write_report(out, summary, matched, signals, gaps, prediction, uncertainty, validation)
        atomic_json(out / "validation.json", validation)
    except Exception as exc:
        validation.update(status="failed", error=str(exc))
        atomic_json(out / "validation.json", validation)
        (out / "REPORT.md").write_text(f"# 분석 검증 실패\n\n원인 결론을 중단했다.\n\n{exc}\n", encoding="utf-8")
        raise
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", required=True)
    parser.add_argument("--validate-only", action="store_true", help="Check saved inputs and reproduce ML metrics first")
    args = parser.parse_args()
    out = analyze(args.suite_dir, args.validate_only)
    print(f"Analysis: {out}", flush=True)


if __name__ == "__main__":
    main()
